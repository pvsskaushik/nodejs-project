const db=require('../model/user');
const path=require('path');
const pad=require('pad');
const multer=require('multer');
const fs=require('fs');
const sizeOf = require('image-size');
const express=require('express');
const app=express();


var count=210;
exports.c=(req,res,next)=>{
    db.countRow((err,result)=>{
        if (err) {
            console.error("Database connection error:", err);
            res.status(500).send("database connection error");
            return;
        }
        else {
            count=result[0].total_rows+1;
            next();
        }
    });
}
//console.log(count);

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const folder = path.join(__dirname, '../uploads', `USR${pad(5, `${count}`, '0')}`);
        // var x=path.join(__dirname, '.', 'uploads');
        // console.log('the path is '+x);
        //let folder=`../server/uploads/USR${pad(5,`${count}`,'0')}`;
        fs.mkdirSync(folder, { recursive: true });
     cb(null, folder)
    },
    filename: function (req, file, cb) {
        let user=`USR${pad(5,`${count}`,'0')}`;
       cb(null, file.fieldname + '-' + user+path.extname(file.originalname))
    }
  })
  
  const fileFilter = function (req, file, cb) {
    const arr=file.originalname.split('.');
   // console.log(arr[1]);
    if(file.fieldname==='resume' && (arr[1]==='pdf' ||  arr[1]==='docx') ){
        cb(null, true);
    }
    else if(file.fieldname==='img' && arr[1]==='png' ){
        cb(null, true);
    }
   else {
      cb(null, false);
    }
  };
  
  exports.upload = multer({ storage: storage, fileFilter: fileFilter });

  exports.createUser=(req,res)=>{
   // console.log((req.files.img));
    if(!req.files.resume || !req.files.img ){
        res.status(400).send("<h1>Upload the Proper Format of the files</h1>");
        res.end();
    } 
    else{
        
         const dimension=sizeOf(req.files.img[0].path);
        // console.log(dimension);
         if(req.files.resume && dimension.height<=400 && dimension.width <=300 && req.files.img[0].size<=1024000){
             
            // console.log(count);
             let user={...req.body};
             const rPath=req.files.resume[0].path;
            const picPath= req.files.img[0].path;
            user['resume']=rPath;
            user['profile']=picPath;
            user['id']=`USR${pad(5,`${count}`,'0')}`;
             //res.send(user);
             db.createUser(user,(err)=>{
                 if(err) {
                    res.status(500).send("<h1>showing error</h1>")
                 }
                 else {
                     count++;
                     res.status(201).send("<h1>sucess</h1>");
                 }
             })
             
         }else{
             const p=path.dirname(req.files.img[0].path);
             //console.log(path);
             fs.rm(p, { recursive: true }, err => {
                 if (err) {
                  console.log("file errors");
                 }
               
                
               })
             res.status(400).send('image should be in the format of 400x300');
             res.end();
         }
    }
  
    
 }
