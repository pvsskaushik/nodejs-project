const sql=require('mysql');
const config=require('../config/config')
const db=sql.createConnection({
    host: config.host,
    user: config.user,
    password: config.password,
    database: config.database,
});

db.connect((err)=>{
    if(err)throw err;
    else console.log('successfully connected to database');
});
const query = 'SELECT COUNT(*) AS total_rows FROM students';
exports.countRow=(callback)=>{
    db.query(query,callback);
}
exports.createUser=(user,callback)=>{
    db.query( `INSERT INTO students ( name, age,city,mobile,email,
        resume,photo) VALUES ( '${user.name}', '${user.age}'
        ,'${user.city}',${user.mobile},'${user.email}','${(user.resume).substring(75)}'
        ,'${(user.profile).substring(74)}')`,callback);
}