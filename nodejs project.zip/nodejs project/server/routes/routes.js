const express=require('express');
const router=express.Router();
const controller=require('../controller/user');
const path=require('path');
router.use('', express.static(path.join(__dirname, '../..', 'client')));
router.post('/api/users/',controller.c,controller.upload.fields([{name:'img'},{name:'resume'}]),
        controller.createUser);
module.exports=router;
