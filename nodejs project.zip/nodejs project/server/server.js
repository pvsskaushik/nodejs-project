const express=require('express');
const app=express();
const routes=require('./routes/routes');

app.use(routes);

const port=4000;
app.listen(port,(err)=>{
    console.log("running on the port number "+port);
})