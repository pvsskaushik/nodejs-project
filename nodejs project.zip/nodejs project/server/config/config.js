let config = {
	"host": "localhost",
	"user": "root",
	"password": "",
	"database": "data"
}

module.exports = config;